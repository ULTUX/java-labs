#!/bin/bash
java  -Djava.security.manager -Djava.security.policy=java.policy -classpath /home/ultux/IdeaProjects/wnowak_252700_java/out/artifacts/enc_dec_lib/enc-dec-lib.jar -jar FileEncryptDecrypt.jar
