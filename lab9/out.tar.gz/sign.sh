#!/bin/bash
jarsigner -keystore keystore -verbose FileEncryptDecrypt.jar jarsign
